## SYDE 572 A1
Author: Cooper Ang (20768006)

Run code related to exercise 1 with  `python a1_ex1.py`

Run code related to exercise 2 with  `python a1_ex2.py`


Please read comments in the code.