## SYDE 572 A3
Author: Cooper Ang (20768006)

Run code related to exercise 1 with  `python a3_ex1.py`

You will need to close the plots manually when running the script.

Run code related to exercise 2 with  `python a3_ex2.py`

Please read comments in the code. Code is not explained in the report and is self documenting.